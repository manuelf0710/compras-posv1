<?php

namespace App\models\pos;

use Illuminate\Database\Eloquent\Model;

class ProductoPrecioLista extends Model
{
    //
}
